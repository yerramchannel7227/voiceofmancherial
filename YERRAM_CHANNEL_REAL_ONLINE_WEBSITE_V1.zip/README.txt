YERRAM CHANNEL REAL ONLINE WEBSITE V1

Features: Telugu responsive news site, categories, Admin login, news editor, photo upload, demo publish.
Demo login: admin / yerram123

IMPORTANT: This package is a starter/demo. It is NOT yet a live internet website. For real online publishing you must connect a domain, hosting, secure server-side authentication, database, image storage and HTTPS. Do not use the demo password in production.